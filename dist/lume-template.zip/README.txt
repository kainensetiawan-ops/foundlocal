Thanks for buying a FoundLocal template!

HOW TO USE
1. Unzip this folder.
2. Open index.html in any browser to preview it.
3. Edit the text/images: open index.html in a free code editor (VS Code), change the words between the tags, swap in your own content.
4. Go live free: drag the folder onto netlify.com (or use Vercel / GitHub Pages / Surge). Done in minutes.
5. Fully responsive — looks great on phone, tablet and desktop.

Need a hand or want it customized? Reach out via my profile.
— FoundLocal
